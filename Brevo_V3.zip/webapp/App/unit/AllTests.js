sap.ui.define([
	"Brevo/Brevo_V2/test/unit/controller/View1.controller"
], function () {
	"use strict";
});